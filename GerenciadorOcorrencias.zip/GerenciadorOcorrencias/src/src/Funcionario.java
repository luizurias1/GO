package src;

public class Funcionario {

	private String name;
	
	public Funcionario(String string) {
		// TODO Auto-generated constructor stub
		this.name = string;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}

}
