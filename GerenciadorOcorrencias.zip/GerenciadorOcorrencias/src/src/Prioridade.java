package src;

public enum Prioridade {
	
	ALTA, MEDIA, BAIXA

}
