package src;

public enum Tipo {
	
	TAREFA, BUG, MELHORIA

}
